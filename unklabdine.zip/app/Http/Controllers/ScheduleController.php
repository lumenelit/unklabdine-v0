<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Schedule;


class ScheduleController extends Controller
{
    public function main() {
        $quote = DB::table('quotes')->get();
        $fday = date('d F Y');
        return view('schedule', ['quote'=>$quote, 'test'=>$fday]);
    }
}
